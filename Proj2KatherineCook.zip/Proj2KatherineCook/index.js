let express=require("express");

//to connect the testdata.html you need to access path
let path = require("path");

//creataing an express application object that pulls all of the methods
let app = express();

//this is constant and the port you go to
const port = 3000

// the / represents the home page. Arrows have a parameter, they are an anoynomous function.
//this is the get method associated with the app object
// app.get("/", (req, res) => res.send("Welcome to the thunderdome!"));
app.get("/", (req,res) =>
{
    res.sendFile(path.join(__dirname + "/index.html"));
});

//allowance to connect html pages
app.use(express.urlencoded({extended: true}));

//how to redirect to other website
app.get("/help", (req,res) => res.redirect("https://humantraffickinghotline.org/"));

//to connect the html pages
app.get("/traffick", (req,res) =>
{
    res.sendFile(path.join(__dirname + "/pages/traffickdata.html"));
});

app.get("/about", (req,res) =>
{
    res.sendFile(path.join(__dirname + "/pages/about.html"));
});

app.get("/contact", (req,res) =>
{
    res.sendFile(path.join(__dirname + "/pages/contactUs.html"));
});


//the app is the obj that has different methods, 1 method is listen
app.listen(port, () => console.log("I am listening"));

//connects to assets folder
app.use(express.static(__dirname, + '/assets'));

